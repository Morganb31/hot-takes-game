HOT TAKES TEAM BATTLE — GRAND FINALE EDITION

Changes: 60-second synchronized preparation countdown; 120-second synchronized debate countdown; host can award a point after debate, end the game at any time, and reveal final scores and winner with a separate button. Scores stay hidden until the grand reveal. Timers reach zero but do not automatically advance; the host controls the transitions.

UPDATE GITHUB: Replace server.js and index.html in your existing repository. Keep package.json as-is. Commit both changes. Render will redeploy automatically if auto-deploy is enabled. Wait for Live and refresh the site. Existing active rooms reset when the server restarts.

For reliable timing, use the host phone to advance stages. A tied final score displays IT’S A TIE.
